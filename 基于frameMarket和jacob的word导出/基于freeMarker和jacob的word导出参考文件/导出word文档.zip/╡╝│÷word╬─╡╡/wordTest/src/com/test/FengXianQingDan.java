package com.test;

public class FengXianQingDan {
	private String fxxh;    //�������
	private String yijfx;   //һ������	
	private String erjfx;   //��������
	private String sanjfx;  //��������
	private String mojfx;   //ĩ������

	public FengXianQingDan() {
		// TODO Auto-generated constructor stub
	}

	public FengXianQingDan(String fxxh, String yijfx, String erjfx,
			String sanjfx, String mojfx) {
		super();
		this.fxxh = fxxh;
		this.yijfx = yijfx;
		this.erjfx = erjfx;
		this.sanjfx = sanjfx;
		this.mojfx = mojfx;
	}

	public String getFxxh() {
		return fxxh;
	}

	public void setFxxh(String fxxh) {
		this.fxxh = fxxh;
	}

	public String getYijfx() {
		return yijfx;
	}

	public void setYijfx(String yijfx) {
		this.yijfx = yijfx;
	}

	public String getErjfx() {
		return erjfx;
	}

	public void setErjfx(String erjfx) {
		this.erjfx = erjfx;
	}

	public String getSanjfx() {
		return sanjfx;
	}

	public void setSanjfx(String sanjfx) {
		this.sanjfx = sanjfx;
	}

	public String getMojfx() {
		return mojfx;
	}

	public void setMojfx(String mojfx) {
		this.mojfx = mojfx;
	}

}
