package com.test;

import java.util.List;

public class DocPO {
	private String post;// ��ҳ�����ܺ�ҳü
	private String year;// ��ҳ����
	private String month;// ��ҳ����
	private String day;// ��ҳ����
	private String duty;// ��λְ��ְ��
	private List<FengXianQingDan> fxqd;//�����嵥
	private List<LiuChengQingDan> lcqd;// �����嵥
	private List<ZhiDuJianSheQingKuang> zdjsqk;// �ƶȽ������
	private List<LiuChengJiPeiTaoGuiFan> lcjptgf;//���̼����׹淶
	private List<DuiYingDeZhiDuBiaoZhun> dydzdbz;  //��Ӧ���ƶȱ�׼
	private List<DuiYingDeYeWuQuanXian> dydywqx;  //��Ӧ��ҵ��Ȩ��
	private int isState; 	 //�ܲ�
	private int isProvince;   //ʡ
	private int isCity;       //��
	private int isCountry;    //��
	private int sjdlcbzgs;// �漰�����̲������
	private int yzddlcbzgs;// ���ƶȵ����̲������
	
	private List<TestTable> testTable;//
	
	private String picStr;
	

	public String getPicStr() {
		return picStr;
	}

	public void setPicStr(String picStr) {
		this.picStr = picStr;
	}

	public DocPO() {
		super();
	}

	public DocPO(String post, String year, String month, String day,
			String duty, List<FengXianQingDan> fxqd,
			List<LiuChengQingDan> lcqd, List<ZhiDuJianSheQingKuang> zdjsqk,
			List<LiuChengJiPeiTaoGuiFan> lcjptgf,
			List<DuiYingDeZhiDuBiaoZhun> dydzdbz,
			List<DuiYingDeYeWuQuanXian> dydywqx, int isState, int isProvince,
			int isCity, int isCountry, int sjdlcbzgs, int yzddlcbzgs,
			List<TestTable> testTable, String picStr) {
		super();
		this.post = post;
		this.year = year;
		this.month = month;
		this.day = day;
		this.duty = duty;
		this.fxqd = fxqd;
		this.lcqd = lcqd;
		this.zdjsqk = zdjsqk;
		this.lcjptgf = lcjptgf;
		this.dydzdbz = dydzdbz;
		this.dydywqx = dydywqx;
		this.isState = isState;
		this.isProvince = isProvince;
		this.isCity = isCity;
		this.isCountry = isCountry;
		this.sjdlcbzgs = sjdlcbzgs;
		this.yzddlcbzgs = yzddlcbzgs;
		this.testTable = testTable;
		this.picStr = picStr;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getDuty() {
		return duty;
	}

	public void setDuty(String duty) {
		this.duty = duty;
	}

	public List<FengXianQingDan> getFxqd() {
		return fxqd;
	}

	public void setFxqd(List<FengXianQingDan> fxqd) {
		this.fxqd = fxqd;
	}

	public List<LiuChengQingDan> getLcqd() {
		return lcqd;
	}

	public void setLcqd(List<LiuChengQingDan> lcqd) {
		this.lcqd = lcqd;
	}

	public List<ZhiDuJianSheQingKuang> getZdjsqk() {
		return zdjsqk;
	}

	public void setZdjsqk(List<ZhiDuJianSheQingKuang> zdjsqk) {
		this.zdjsqk = zdjsqk;
	}

	public List<LiuChengJiPeiTaoGuiFan> getLcjptgf() {
		return lcjptgf;
	}

	public void setLcjptgf(List<LiuChengJiPeiTaoGuiFan> lcjptgf) {
		this.lcjptgf = lcjptgf;
	}

	public List<DuiYingDeZhiDuBiaoZhun> getDydzdbz() {
		return dydzdbz;
	}

	public void setDydzdbz(List<DuiYingDeZhiDuBiaoZhun> dydzdbz) {
		this.dydzdbz = dydzdbz;
	}

	public List<DuiYingDeYeWuQuanXian> getDydywqx() {
		return dydywqx;
	}

	public void setDydywqx(List<DuiYingDeYeWuQuanXian> dydywqx) {
		this.dydywqx = dydywqx;
	}

	public int getIsState() {
		return isState;
	}

	public void setIsState(int isState) {
		this.isState = isState;
	}

	public int getIsProvince() {
		return isProvince;
	}

	public void setIsProvince(int isProvince) {
		this.isProvince = isProvince;
	}

	public int getIsCity() {
		return isCity;
	}

	public void setIsCity(int isCity) {
		this.isCity = isCity;
	}

	public int getIsCountry() {
		return isCountry;
	}

	public void setIsCountry(int isCountry) {
		this.isCountry = isCountry;
	}

	public int getSjdlcbzgs() {
		return sjdlcbzgs;
	}

	public void setSjdlcbzgs(int sjdlcbzgs) {
		this.sjdlcbzgs = sjdlcbzgs;
	}

	public int getYzddlcbzgs() {
		return yzddlcbzgs;
	}

	public void setYzddlcbzgs(int yzddlcbzgs) {
		this.yzddlcbzgs = yzddlcbzgs;
	}

	public List<TestTable> getTestTable() {
		return testTable;
	}

	public void setTestTable(List<TestTable> testTable) {
		this.testTable = testTable;
	}


}
