package com.test;

public class LiuChengBuZhou {
	private int count;    //����˳�� �����������
	private String lcbzbh;//���̲�����
	private String lcbzmc;//���̲�������
	private String gzcx;//��������
	private String gzbz;//������׼
	private String srxx;//������Ϣ
	private String srxxtgz;//������Ϣ�ṩ��
	private String scxx;  //�����Ϣ
	private String sjxxxt; //�����Ϣϵͳ
	
	public LiuChengBuZhou(int count, String lcbzbh, String lcbzmc, String gzcx,
			String gzbz, String srxx, String srxxtgz, String scxx, String sjxxxt) {
		super();
		this.count = count;
		this.lcbzbh = lcbzbh;
		this.lcbzmc = lcbzmc;
		this.gzcx = gzcx;
		this.gzbz = gzbz;
		this.srxx = srxx;
		this.srxxtgz = srxxtgz;
		this.scxx = scxx;
		this.sjxxxt = sjxxxt;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getLcbzbh() {
		return lcbzbh;
	}
	public void setLcbzbh(String lcbzbh) {
		this.lcbzbh = lcbzbh;
	}
	public String getLcbzmc() {
		return lcbzmc;
	}
	public void setLcbzmc(String lcbzmc) {
		this.lcbzmc = lcbzmc;
	}
	public String getGzcx() {
		return gzcx;
	}
	public void setGzcx(String gzcx) {
		this.gzcx = gzcx;
	}
	public String getGzbz() {
		return gzbz;
	}
	public void setGzbz(String gzbz) {
		this.gzbz = gzbz;
	}
	public String getSrxx() {
		return srxx;
	}
	public void setSrxx(String srxx) {
		this.srxx = srxx;
	}
	public String getSrxxtgz() {
		return srxxtgz;
	}
	public void setSrxxtgz(String srxxtgz) {
		this.srxxtgz = srxxtgz;
	}
	public String getScxx() {
		return scxx;
	}
	public void setScxx(String scxx) {
		this.scxx = scxx;
	}
	public String getSjxxxt() {
		return sjxxxt;
	}
	public void setSjxxxt(String sjxxxt) {
		this.sjxxxt = sjxxxt;
	}

	
}
