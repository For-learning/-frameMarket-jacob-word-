package com.test;

public class DuiYingDeZhiDuBiaoZhun {
	private String zdbz;  //��Ӧ���ƶȱ�׼

	public DuiYingDeZhiDuBiaoZhun() {
		// TODO Auto-generated constructor stub
	}

	public DuiYingDeZhiDuBiaoZhun(String zdbz) {
		super();
		this.zdbz = zdbz;
	}

	public String getZdbz() {
		return zdbz;
	}

	public void setZdbz(String zdbz) {
		this.zdbz = zdbz;
	}
	
	

}
