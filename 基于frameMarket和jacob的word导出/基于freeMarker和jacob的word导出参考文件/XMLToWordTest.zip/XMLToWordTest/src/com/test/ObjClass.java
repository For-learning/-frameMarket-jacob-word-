package com.test;

public class ObjClass {
	private int xh;
	private String lcmc;
	private String gwsjlcjd;
	private String jdzz;
	
	public ObjClass() {
		super();
	}
	public ObjClass(int xh, String lcmc, String gwsjlcjd, String jdzz) {
		super();
		this.xh = xh;
		this.lcmc = lcmc;
		this.gwsjlcjd = gwsjlcjd;
		this.jdzz = jdzz;
	}
	public int getXh() {
		return xh;
	}
	public void setXh(int xh) {
		this.xh = xh;
	}
	public String getLcmc() {
		return lcmc;
	}
	public void setLcmc(String lcmc) {
		this.lcmc = lcmc;
	}
	public String getGwsjlcjd() {
		return gwsjlcjd;
	}
	public void setGwsjlcjd(String gwsjlcjd) {
		this.gwsjlcjd = gwsjlcjd;
	}
	public String getJdzz() {
		return jdzz;
	}
	public void setJdzz(String jdzz) {
		this.jdzz = jdzz;
	}
}
