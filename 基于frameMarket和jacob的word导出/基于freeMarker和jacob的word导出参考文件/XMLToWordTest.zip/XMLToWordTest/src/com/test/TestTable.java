package com.test;

public class TestTable {
	private String processOne;
	private String processTwo;
	private String processThree;
	private String processFour;
	private String processManagerDepartment;
	
	
	public TestTable(String processOne, String processTwo, String processThree,
			String processFour, String processManagerDepartment) {
		super();
		this.processOne = processOne;
		this.processTwo = processTwo;
		this.processThree = processThree;
		this.processFour = processFour;
		this.processManagerDepartment = processManagerDepartment;
	}
	
	public TestTable() {
		super();
	}
	public String getProcessOne() {
		return processOne;
	}
	public void setProcessOne(String processOne) {
		this.processOne = processOne;
	}
	public String getProcessTwo() {
		return processTwo;
	}
	public void setProcessTwo(String processTwo) {
		this.processTwo = processTwo;
	}
	public String getProcessThree() {
		return processThree;
	}
	public void setProcessThree(String processThree) {
		this.processThree = processThree;
	}
	public String getProcessFour() {
		return processFour;
	}
	public void setProcessFour(String processFour) {
		this.processFour = processFour;
	}
	public String getProcessManagerDepartment() {
		return processManagerDepartment;
	}
	public void setProcessManagerDepartment(String processManagerDepartment) {
		this.processManagerDepartment = processManagerDepartment;
	}

	
}