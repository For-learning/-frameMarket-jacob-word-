package com.test;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.swing.text.Document;
import javax.swing.text.html.parser.Element;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Wordtest {
//	public static void expWord() {
//		ZipFile docxFile = new ZipFile(new File("c:/3.docx"));
//		ZipEntry documentXML = docxFile.getEntry("word/document.xml");
//		InputStream documentXMLIS = docxFile.getInputStream(documentXML);
//		String s = "";
//
//		InputStreamReader reader = new InputStreamReader(documentXMLIS, "UTF-8");
//		BufferedReader br = new BufferedReader(reader);
//		String str = null;
//
//		while ((str = br.readLine()) != null) {
//			s = s + str;
//		}
//		s = s.replaceAll("${key}", "�滻����");
//		System.out.println(s);
//		reader.close();
//		br.close();
//		if (true) {
//			// return;
//		}
//		// ZipEntry imgFile = docxFile.getEntry("word/media/image1.png");
//
//		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//		InputStream documentXMLIS1 = docxFile.getInputStream(documentXML);
//		Document doc = dbf.newDocumentBuilder().parse(documentXMLIS1);
//		Element docElement = doc.getDocumentElement();
//		// assertEquals("w:document", docElement.getTagName());
//		Element bodyElement = (Element) docElement.getElementsByTagName(
//				"w:body").item(0);
//		// assertEquals("w:body", bodyElement.getTagName());
//		Element pElement = (Element) bodyElement.getElementsByTagName("w:p")
//				.item(0);
//		// assertEquals("w:p", pElement.getTagName());
//		Element rElement = (Element) pElement.getElementsByTagName("w:r").item(
//				0);
//		// assertEquals("w:r", rElement.getTagName());
//		Element tElement = (Element) rElement.getElementsByTagName("w:t").item(
//				0);
//		// assertEquals("w:t", tElement.getTagName());
//		// assertEquals("���ǵ�һ�������ĵ�", tElement.getTextContent());
//		// tElement.setTextContent("���ǵ�һ����Javaд�Ĳ����ĵ�");
//		Transformer t = TransformerFactory.newInstance().newTransformer();
//		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//		t.transform(new DOMSource(doc), new StreamResult(baos));
//		ZipOutputStream docxOutFile = new ZipOutputStream(new FileOutputStream(
//				"response.docx"));
//		Enumeration<ZipEntry> entriesIter = (Enumeration<ZipEntry>) docxFile
//				.entries();
//		while (entriesIter.hasMoreElements()) {
//			ZipEntry entry = entriesIter.nextElement();
//			System.out.println(entry.getName());
//
//			if (entry.getName().equals("word/document.xml")) {
//				byte[] data = baos.toByteArray();
//				docxOutFile.putNextEntry(new ZipEntry(entry.getName()));
//				byte[] datas = s.getBytes("UTF-8");
//				docxOutFile.write(datas, 0, datas.length);
//				// docxOutFile.write(data, 0, data.length);
//				docxOutFile.closeEntry();
//			} else if (entry.getName().equals("word/media/image1.png")) {
//				InputStream incoming = new FileInputStream("c:/aaa.jpg");
//				byte[] data = new byte[incoming.available()];
//				int readCount = incoming.read(data, 0, data.length);
//				docxOutFile.putNextEntry(new ZipEntry(entry.getName()));
//				docxOutFile.write(data, 0, readCount);
//				docxOutFile.closeEntry();
//			} else {
//				InputStream incoming = docxFile.getInputStream(entry);
//				byte[] data = new byte[incoming.available()];
//				int readCount = incoming.read(data, 0, data.length);
//				docxOutFile.putNextEntry(new ZipEntry(entry.getName()));
//				docxOutFile.write(data, 0, readCount);
//				docxOutFile.closeEntry();
//			}
//		}
//		docxOutFile.close();
//	}
}
