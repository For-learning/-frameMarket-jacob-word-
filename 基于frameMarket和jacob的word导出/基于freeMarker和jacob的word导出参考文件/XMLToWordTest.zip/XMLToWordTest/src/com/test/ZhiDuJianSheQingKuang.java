package com.test;

public class ZhiDuJianSheQingKuang {
	private int bh;// ���
	private String sjdyijlc;// �漰��һ������
	private String sjdmdlcmc;// �漰��ĩ����������
	private int sjdlcbzgs;// �漰�����̲������
	private int yzddlcbzgs;// ���ƶȵ����̲������

	public ZhiDuJianSheQingKuang() {
		super();
	}

	public ZhiDuJianSheQingKuang(int bh, String sjdyijlc, String sjdmdlcmc,
			int sjdlcbzgs, int yzddlcbzgs) {
		super();
		this.bh = bh;
		this.sjdyijlc = sjdyijlc;
		this.sjdmdlcmc = sjdmdlcmc;
		this.sjdlcbzgs = sjdlcbzgs;
		this.yzddlcbzgs = yzddlcbzgs;
	}

	public int getBh() {
		return bh;
	}

	public void setBh(int bh) {
		this.bh = bh;
	}

	public String getSjdyijlc() {
		return sjdyijlc;
	}

	public void setSjdyijlc(String sjdyijlc) {
		this.sjdyijlc = sjdyijlc;
	}

	public String getSjdmdlcmc() {
		return sjdmdlcmc;
	}

	public void setSjdmdlcmc(String sjdmdlcmc) {
		this.sjdmdlcmc = sjdmdlcmc;
	}

	public int getSjdlcbzgs() {
		return sjdlcbzgs;
	}

	public void setSjdlcbzgs(int sjdlcbzgs) {
		this.sjdlcbzgs = sjdlcbzgs;
	}

	public int getYzddlcbzgs() {
		return yzddlcbzgs;
	}

	public void setYzddlcbzgs(int yzddlcbzgs) {
		this.yzddlcbzgs = yzddlcbzgs;
	}

}
