package com.test;

public class LiuChengQingDan {
	private int xh;        //���
	private String yijlc;  //һ������
	private String erjlc;  //��������
	private String sanjlc; //��������
	private String bgwsjlcmc; //����λ�漰��������
	private String lcbh;   //���̱��
	private String bgwsjlcbz; //����λ�漰���̲���

	public LiuChengQingDan() {
		super();
	}

	public LiuChengQingDan(int xh, String yijlc, String erjlc, String sanjlc,
			String bgwsjlcmc, String lcbh, String bgwsjlcbz) {
		super();
		this.xh = xh;
		this.yijlc = yijlc;
		this.erjlc = erjlc;
		this.sanjlc = sanjlc;
		this.bgwsjlcmc = bgwsjlcmc;
		this.lcbh = lcbh;
		this.bgwsjlcbz = bgwsjlcbz;
	}

	public int getXh() {
		return xh;
	}

	public void setXh(int xh) {
		this.xh = xh;
	}

	public String getYijlc() {
		return yijlc;
	}

	public void setYijlc(String yijlc) {
		this.yijlc = yijlc;
	}

	public String getErjlc() {
		return erjlc;
	}

	public void setErjlc(String erjlc) {
		this.erjlc = erjlc;
	}

	public String getSanjlc() {
		return sanjlc;
	}

	public void setSanjlc(String sanjlc) {
		this.sanjlc = sanjlc;
	}

	public String getBgwsjlcmc() {
		return bgwsjlcmc;
	}

	public void setBgwsjlcmc(String bgwsjlcmc) {
		this.bgwsjlcmc = bgwsjlcmc;
	}

	public String getLcbh() {
		return lcbh;
	}

	public void setLcbh(String lcbh) {
		this.lcbh = lcbh;
	}

	public String getBgwsjlcbz() {
		return bgwsjlcbz;
	}

	public void setBgwsjlcbz(String bgwsjlcbz) {
		this.bgwsjlcbz = bgwsjlcbz;
	}
}
