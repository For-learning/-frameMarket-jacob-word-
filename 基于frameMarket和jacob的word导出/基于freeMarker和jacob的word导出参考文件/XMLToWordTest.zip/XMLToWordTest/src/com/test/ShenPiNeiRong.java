package com.test;

public class ShenPiNeiRong {
	private int xuhao;               //0:�ܲ�	1:ʡ		2:��		3:��
	private String bianzhishenqing;  //��������
	private String chushen;          //����
	private String fushen;           //����
	private String shenpi;           //����

	public ShenPiNeiRong() {
		// TODO Auto-generated constructor stub
		super();
	}

	public ShenPiNeiRong(int xuhao, String bianzhishenqing, String chushen,
			String fushen, String shenpi) {
		super();
		this.xuhao = xuhao;
		this.bianzhishenqing = bianzhishenqing;
		this.chushen = chushen;
		this.fushen = fushen;
		this.shenpi = shenpi;
	}

	public int getXuhao() {
		return xuhao;
	}

	public void setXuhao(int xuhao) {
		this.xuhao = xuhao;
	}

	public String getBianzhishenqing() {
		return bianzhishenqing;
	}

	public void setBianzhishenqing(String bianzhishenqing) {
		this.bianzhishenqing = bianzhishenqing;
	}

	public String getChushen() {
		return chushen;
	}

	public void setChushen(String chushen) {
		this.chushen = chushen;
	}

	public String getFushen() {
		return fushen;
	}

	public void setFushen(String fushen) {
		this.fushen = fushen;
	}

	public String getShenpi() {
		return shenpi;
	}

	public void setShenpi(String shenpi) {
		this.shenpi = shenpi;
	}

}
