package com.test;

import java.util.List;

public class DuiYingDeYeWuQuanXian {
	private String mdlcbh; 		 //ĩ�����̱��
	private String mdlcmc; 		 //ĩ����������
	private String spsx;   		 //��������
	private String sqje;   		 //��Ȩ���
	private String sfsyzdsx;  	 //�Ƿ������ش�����
	private String zdsxlb; 		 //�ش��������
	private String zdsxnr; 		 //�ش���������
	private String spfs;   		 //������ʽ
	private int isState; 	 //�ܲ�
	private int isProvince;   //ʡ
	private int isCity;       //��
	private int isCountry;    //��
	private String zongbu; 	 //�ܲ�
	private String sheng;   //ʡ
	private String shi;       //��
	private String xian;    //��
	private ShenPiNeiRong  spnrzb;   //�ܲ���������
	private ShenPiNeiRong  spnrsh;   //ʡ��������
	private ShenPiNeiRong  spnrds;   //������������
	private ShenPiNeiRong  spnrxi;   //����������
	private String yzm;      //ӡ����
	private String yzbgbm;   //ӡ�±��ܲ���

	public DuiYingDeYeWuQuanXian() {
		// TODO Auto-generated constructor stub
	}

	public DuiYingDeYeWuQuanXian(String mdlcbh, String mdlcmc, String spsx,
			String sqje, String sfsyzdsx, String zdsxlb, String zdsxnr,
			String spfs, int isState, int isProvince, int isCity,
			int isCountry, String zongbu, String sheng, String shi,
			String xian, ShenPiNeiRong spnrzb, ShenPiNeiRong spnrsh,
			ShenPiNeiRong spnrds, ShenPiNeiRong spnrxi, String yzm,
			String yzbgbm) {
		super();
		this.mdlcbh = mdlcbh;
		this.mdlcmc = mdlcmc;
		this.spsx = spsx;
		this.sqje = sqje;
		this.sfsyzdsx = sfsyzdsx;
		this.zdsxlb = zdsxlb;
		this.zdsxnr = zdsxnr;
		this.spfs = spfs;
		this.isState = isState;
		this.isProvince = isProvince;
		this.isCity = isCity;
		this.isCountry = isCountry;
		this.zongbu = zongbu;
		this.sheng = sheng;
		this.shi = shi;
		this.xian = xian;
		this.spnrzb = spnrzb;
		this.spnrsh = spnrsh;
		this.spnrds = spnrds;
		this.spnrxi = spnrxi;
		this.yzm = yzm;
		this.yzbgbm = yzbgbm;
	}

	public String getMdlcbh() {
		return mdlcbh;
	}

	public void setMdlcbh(String mdlcbh) {
		this.mdlcbh = mdlcbh;
	}

	public String getMdlcmc() {
		return mdlcmc;
	}

	public void setMdlcmc(String mdlcmc) {
		this.mdlcmc = mdlcmc;
	}

	public String getSpsx() {
		return spsx;
	}

	public void setSpsx(String spsx) {
		this.spsx = spsx;
	}

	public String getSqje() {
		return sqje;
	}

	public void setSqje(String sqje) {
		this.sqje = sqje;
	}

	public String getSfsyzdsx() {
		return sfsyzdsx;
	}

	public void setSfsyzdsx(String sfsyzdsx) {
		this.sfsyzdsx = sfsyzdsx;
	}

	public String getZdsxlb() {
		return zdsxlb;
	}

	public void setZdsxlb(String zdsxlb) {
		this.zdsxlb = zdsxlb;
	}

	public String getZdsxnr() {
		return zdsxnr;
	}

	public void setZdsxnr(String zdsxnr) {
		this.zdsxnr = zdsxnr;
	}

	public String getSpfs() {
		return spfs;
	}

	public void setSpfs(String spfs) {
		this.spfs = spfs;
	}

	public int getIsState() {
		return isState;
	}

	public void setIsState(int isState) {
		this.isState = isState;
	}

	public int getIsProvince() {
		return isProvince;
	}

	public void setIsProvince(int isProvince) {
		this.isProvince = isProvince;
	}

	public int getIsCity() {
		return isCity;
	}

	public void setIsCity(int isCity) {
		this.isCity = isCity;
	}

	public int getIsCountry() {
		return isCountry;
	}

	public void setIsCountry(int isCountry) {
		this.isCountry = isCountry;
	}

	public String getZongbu() {
		return zongbu;
	}

	public void setZongbu(String zongbu) {
		this.zongbu = zongbu;
	}

	public String getSheng() {
		return sheng;
	}

	public void setSheng(String sheng) {
		this.sheng = sheng;
	}

	public String getShi() {
		return shi;
	}

	public void setShi(String shi) {
		this.shi = shi;
	}

	public String getXian() {
		return xian;
	}

	public void setXian(String xian) {
		this.xian = xian;
	}

	public ShenPiNeiRong getSpnrzb() {
		return spnrzb;
	}

	public void setSpnrzb(ShenPiNeiRong spnrzb) {
		this.spnrzb = spnrzb;
	}

	public ShenPiNeiRong getSpnrsh() {
		return spnrsh;
	}

	public void setSpnrsh(ShenPiNeiRong spnrsh) {
		this.spnrsh = spnrsh;
	}

	public ShenPiNeiRong getSpnrds() {
		return spnrds;
	}

	public void setSpnrds(ShenPiNeiRong spnrds) {
		this.spnrds = spnrds;
	}

	public ShenPiNeiRong getSpnrxi() {
		return spnrxi;
	}

	public void setSpnrxi(ShenPiNeiRong spnrxi) {
		this.spnrxi = spnrxi;
	}

	public String getYzm() {
		return yzm;
	}

	public void setYzm(String yzm) {
		this.yzm = yzm;
	}

	public String getYzbgbm() {
		return yzbgbm;
	}

	public void setYzbgbm(String yzbgbm) {
		this.yzbgbm = yzbgbm;
	}

}
