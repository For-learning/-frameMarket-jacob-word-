package com.test;

import java.util.List;

public class LiuChengJiPeiTaoGuiFan {
	private int lcxh;//������� �����������
	private String lcmc;//��������
	private String imageId;//����ͼƬid
	private String imageName;//����ͼƬ����
	private String imageCode;//����ͼƬ����
	private List<LiuChengBuZhou> lcbz;//���̲���
	
	public LiuChengJiPeiTaoGuiFan(int lcxh, String lcmc, String imageId,
			String imageName, String imageCode, List<LiuChengBuZhou> lcbz) {
		super();
		this.lcxh = lcxh;
		this.lcmc = lcmc;
		this.imageId = imageId;
		this.imageName = imageName;
		this.imageCode = imageCode;
		this.lcbz = lcbz;
	}
	public String getLcmc() {
		return lcmc;
	}
	public void setLcmc(String lcmc) {
		this.lcmc = lcmc;
	}
	public List<LiuChengBuZhou> getLcbz() {
		return lcbz;
	}
	public void setLcbz(List<LiuChengBuZhou> lcbz) {
		this.lcbz = lcbz;
	}
	public int getLcxh() {
		return lcxh;
	}
	public void setLcxh(int lcxh) {
		this.lcxh = lcxh;
	}
	public String getImageId() {
		return imageId;
	}
	public void setImageId(String imageId) {
		this.imageId = imageId;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getImageCode() {
		return imageCode;
	}
	public void setImageCode(String imageCode) {
		this.imageCode = imageCode;
	}

}
