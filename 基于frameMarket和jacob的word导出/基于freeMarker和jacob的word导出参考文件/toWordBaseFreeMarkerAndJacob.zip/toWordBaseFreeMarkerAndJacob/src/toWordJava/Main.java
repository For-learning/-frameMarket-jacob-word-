package toWordJava;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import sun.misc.BASE64Encoder;

public class Main {
	public static void main(String[] args) throws Exception {
		// 创建数据源
		Person person = new Person();
		person.setName("小强");
		person.setAge(6);
		List<String> listTemp = new ArrayList<String>();
		listTemp.add("123");
		listTemp.add("456");
		listTemp.add("789");
		person.setList(listTemp);

		// 生成基于xml的word文档
		// 要生成的临时的基于xml的word的地址和名称
		String topath = "/toWordFile/" + UUID.randomUUID().toString() + ".doc";
		DocumentHandler<Person> documentHandler = new DocumentHandler<Person>();
		documentHandler.createDoc(person, "/toWordFile/", topath,
				"emportTestFile.ftl");
		// 生成真正的word文档
		documentHandler.XMLToDocHandler(topath, "F:\\123.doc");
	}

	/**
	 * 生成文件的base64位编码，对于图片可以使用这个方法，获取图片路径后
	 * 生成其BASE64编码封装到对象中，因为word的图片就是采用的这个编码形式
	 * 
	 * @param imagePath
	 * @return
	 */
	public String GetImageStr(String imagePath) {// 将图片文件转化为字节数组字符串，并对其进行Base64编码处理
		String imgFile = imagePath;// 待处理的图片
		InputStream in = null;
		byte[] data = null;
		// 读取图片字节数组
		try {
			in = new FileInputStream(imgFile);
			data = new byte[in.available()];
			in.read(data);
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 对字节数组Base64编码
		BASE64Encoder encoder = new BASE64Encoder();
		return encoder.encode(data);// 返回Base64编码过的字节数组字符串
	}
}
