package toWordJava;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

/**
 * @author clown 泛型类，用于处理输出的模板
 * @param <T>
 */
public class DocumentHandler<T> {

	private Configuration configuration = null;

	public DocumentHandler() {
		configuration = new Configuration();
		// 设置配置文件的编码形式
		configuration.setDefaultEncoding("utf-8");
	}

	/**
	 * @param dataList
	 *            数据源
	 * @param fromPath
	 *            ftl模板路径
	 * @param toPath
	 *            基于xml的word的输出路径
	 * @param templateName
	 *            ftl模板名称
	 * @throws IOException
	 */
	public void createDoc(T dataList, String fromPath, String toPath,
			String templateName) throws IOException {
		Map<String, T> dataMap = new HashMap<String, T>();
		dataMap.put("dataList", dataList);
		// 下面这个是基于类路径下取文件，
		// configuration.setClassForTemplateLoading(this.getClass(),
		// "/toWordFile/");
		// 基于文件系统路径下取文件
		configuration.setDirectoryForTemplateLoading(new File(fromPath));
		Template t = null;
		try {
			// fileName为要装载的模板
			t = configuration.getTemplate(templateName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		// 输出文档路径及名称
		File outFile = new File(toPath);
		Writer out = null;
		try {
			out = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(outFile)));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}

		try {
			// 将要打印的文档输出到framemark模板下面
			t.process(dataMap, out);
		} catch (TemplateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	/**
	 * @param FromPathAndFileName
	 *            基于xml格式的word文档地址
	 * @param toPathAndFileName
	 *            输出真正word的地址
	 * @return 返回文件输出的地址
	 */
	public String XMLToDocHandler(String FromPathAndFileName,
			String toPathAndFileName) {
		// 初始化
		ActiveXComponent app = null;
		try {
			// 初始化com的线程
			ComThread.InitSTA();
			app = new ActiveXComponent("Word.Application");
			// 设置Word不可见状态
			app.setProperty("Visible", false);
			// 调用Application对象的Documents属性，获得Documents对象
			Dispatch docs = app.getProperty("Documents").toDispatch();
			// 读取word文档
			Dispatch doc = Dispatch.call(docs, "Open", FromPathAndFileName,
					new Variant(false), new Variant(true)).getDispatch();

			// 进行文档的转换，即将基于xml的word转换为真正的word文档，0代表doc格式，12代表docx格式的。
			Dispatch.call(doc, "SaveAS", toPathAndFileName, 0);
			// 关闭打开的Word文件并设置不保存改状态
			Dispatch.call(doc, "Close", false);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭Word应用程序
			app.invoke("Quit", 0);
			// 释放com线程。根据jacob的帮助文档，com的线程回收不由java的垃圾回收器处理
			ComThread.Release();
			// 删除生成的临时文件
			File file = new File(FromPathAndFileName);
			if (file.exists()) {
				file.delete();
			}
		}
		return toPathAndFileName;

	}
	// Dispatch.call(doc, "SaveAS", toPathAndFileName, 0);中转成word的格式问题
	// 0:Microsoft Word 97 - 2003 文档 (.doc)
	// 1:Microsoft Word 97 - 2003 模板 (.dot)
	// 2:文本文档 (.txt)
	// 3:文本文档 (.txt)
	// 4:文本文档 (.txt)
	// 5:文本文档 (.txt)
	// 6:RTF 格式 (.rtf)
	// 7:文本文档 (.txt)
	// 8:HTML 文档 (.htm)(带文件夹)
	// 9:MHTML 文档 (.mht)(单文件)
	// 10:MHTML 文档 (.mht)(单文件)
	// 11:XML 文档 (.xml)
	// 12:Microsoft Word 文档 (.docx)
	// 13:Microsoft Word 启用宏的文档 (.docm)
	// 14:Microsoft Word 模板 (.dotx)
	// 15:Microsoft Word 启用宏的模板 (.dotm)
	// 16:Microsoft Word 文档 (.docx)
	// 17:PDF 文件 (.pdf)
	// 18:XPS 文档 (.xps)
	// 19:XML 文档 (.xml)
	// 20:XML 文档 (.xml)
	// 21:XML 文档 (.xml)
	// 22:XML 文档 (.xml)
	// 23:OpenDocument 文本 (.odt)
	// 24:WTF 文件 (.wtf)
}
