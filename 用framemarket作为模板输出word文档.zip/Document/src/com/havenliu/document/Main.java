package com.havenliu.document;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DocumentHandler dh=new DocumentHandler();
		dh.createDoc();
	}

}
